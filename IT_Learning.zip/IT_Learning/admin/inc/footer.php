 </div>

        <div class="footer">
            <p>© 2025 EduTech - Sistem Pendaftaran Kursus Komputer. All rights reserved.</p>
        </div>
    </div>
</body>
</html>